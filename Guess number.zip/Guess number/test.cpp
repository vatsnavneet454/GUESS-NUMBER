#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

int main() {
    cout << "Content-Type: text/html\n\n";

    int randomNumber;
    int attempts;
    string previousGuesses = "";
    string message = "";

    // ---------- LOAD OR CREATE GAME STATE ----------
    ifstream infile("state.txt");
    if (infile) {
        infile >> randomNumber >> attempts;
        infile.ignore();
        getline(infile, previousGuesses);
        infile.close();
    } else {
        srand(time(0));
        randomNumber = rand() % 100 + 1; // ✅ 1 to 100
        attempts = 10;                  // ✅ 10 attempts
    }

    // ---------- GET USER INPUT ----------
    char* data = getenv("QUERY_STRING");

    if (data && attempts > 0) {
        int guess;
        sscanf(data, "num=%d", &guess);

        // ---------- VALIDATION ----------
        if (guess < 1 || guess > 100) {
            message = "❗ Enter a number between 1 and 100";
        } else {
            attempts--;

            if (previousGuesses.empty())
                previousGuesses = to_string(guess);
            else
                previousGuesses += ", " + to_string(guess);

            if (guess > randomNumber)
                message = "Hint: Your guess is TOO HIGH";
            else if (guess < randomNumber)
                message = "Hint: Your guess is TOO LOW";
            else {
                // ---------- WIN ----------
                cout << "<html><head>";
                cout << "<link rel='stylesheet' href='/style.css'>";
                cout << "</head><body><div class='game-box'>";
                cout << "<h2>Number Guessing Game</h2>";
                cout << "<h3 style='color:green'>🎉 You guessed it RIGHT!</h3>";
                cout << "<p><b>Your guesses:</b> " << previousGuesses << "</p>";
                remove("state.txt");
                cout << "<form action='/test.html'>";
                cout << "<button>Start New Game</button>";
                cout << "</form>";
                cout << "</div></body></html>";
                return 0;
            }
        }
    }

    // ---------- GAME OVER ----------
    if (attempts == 0) {
        cout << "<html><head>";
        cout << "<link rel='stylesheet' href='/style.css'>";
        cout << "</head><body><div class='game-box'>";
        cout << "<h2>Number Guessing Game</h2>";
        cout << "<h3 style='color:red'> Game Over</h3>";
        cout << "<p>Correct number was: <b>" << randomNumber << "</b></p>";
        cout << "<p><b>Your guesses:</b> " << previousGuesses << "</p>";
        remove("state.txt");
        cout << "<form action='/test.html'>";
        cout << "<button>Start New Game</button>";
        cout << "</form>";
        cout << "</div></body></html>";
        return 0;
    }

    // ---------- SAVE STATE ----------
    ofstream outfile("state.txt");
    outfile << randomNumber << " " << attempts << "\n" << previousGuesses;
    outfile.close();

    // ---------- UI (ORDER AS YOU WANTED) ----------
    cout << "<html><head>";
    cout << "<link rel='stylesheet' href='/style.css'>";
    cout << "</head><body><div class='game-box'>";

    cout << "<h2>Number Guessing Game</h2>";
    cout << "<p>Guess a number between <b>1 and 100</b></p>";

    // Input + submit (top)
    cout << "<form method='get' action='/cgi-bin/test.cgi'>";
    cout << "<input type='number' name='num' required>";
    cout << "<button type='submit'>Submit</button>";
    cout << "</form>";

    // Hint
    if (!message.empty())
        cout << "<p style='color:yellow; font-weight:bold'>" << message << "</p>";

    // Status
    cout << "<p><b>Attempts Left:</b> " << attempts << "</p>";
    cout << "<p><b>Previous Guesses:</b> "
         << (previousGuesses.empty() ? "None" : previousGuesses) << "</p>";

    // Start new game (bottom)
    cout << "<form action='/test.html'>";
    cout << "<button>Start New Game</button>";
    cout << "</form>";

    cout << "</div></body></html>";
    return 0;
}
